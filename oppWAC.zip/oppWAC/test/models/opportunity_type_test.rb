require 'test_helper'

class OpportunityTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
