require 'test_helper'

class BetaUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
