# Preview all emails at http://localhost:3000/rails/mailers/opp_welcome
class OppWelcomePreview < ActionMailer::Preview
end
