require 'test_helper'

class MatchMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
