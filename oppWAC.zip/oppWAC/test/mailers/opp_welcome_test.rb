require 'test_helper'

class OppWelcomeTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
