class BetaUser < ApplicationRecord
end
