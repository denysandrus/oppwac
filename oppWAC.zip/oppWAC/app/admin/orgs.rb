ActiveAdmin.register_page 'Orgs' do
  content do
    render partial: '/orgs'
  end
end
