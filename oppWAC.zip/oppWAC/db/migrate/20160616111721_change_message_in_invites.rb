class ChangeMessageInInvites < ActiveRecord::Migration[4.2]
  def change
  end
end
